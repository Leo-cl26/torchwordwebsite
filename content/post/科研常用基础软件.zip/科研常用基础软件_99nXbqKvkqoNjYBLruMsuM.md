# 科研常用基础软件

> 这里收集了一些常用的科研软件，合理使用它们，可以帮助你更好地完成工作哦。(๑• . •๑)

## 1.简单易用的视频分析软件——Tracker

### 教程

<https://www.zhihu.com/answer/2071496637>

### 官网

<https://www.physlets.org/tracker/>

## 2.标准科研制图——Origin

### 教程

<http://lovephysics.sysu.edu.cn/doku.php?id=courses:firstlevel:exp0_2&s[]=origin>

### 官网

<https://www.originlab.com/origin>

## 3.用手机做实验——Phyphox

### 下载地址(提取码：sysu)

<https://pan.baidu.com/s/1BkFr72R-c7p68RUfjpF0xQ?pwd=sysu>

### 官网

<https://phyphox.org/>

## 4.集成数学工具——Mathematica/Matlab

### 教程

[Mathematica入门教程](https://www.wolai.com/u2G54czSnNdQYEpUMnd65E "Mathematica入门教程")

<https://www.mathworks.com/help/overview/mathematics-and-optimization.html?s_tid=hc_panel>

### 下载地址(提取码：6662)

<https://pan.baidu.com/s/1wF5wR6ckZj0zSxDi5eniIA>

<https://software.sysu.edu.cn/matlabhome>

## 5.集成图像处理工具——ImageJ

### 教程

<https://zhuanlan.zhihu.com/p/60999196>

### 官网

<https://imagej.net/software/fiji/downloads>

## 6.手写公式识别——Mathpix

### 官网

<https://mathpix.com/>

## 7.示意图也重要——PowerPoint

![](image/78db97acaf8e828a7325751db6f6895_Nm3Q2ZTXF9.jpg)

### 教程

[PPT绘图入门](https://www.wolai.com/8rAjpMU1QnfAH7jVDfKvYf "PPT绘图入门")

### 下载地址

<https://ms.sysu.edu.cn/>

## 8.画张思维导图吧——Proecesson/幕布/Visio

### 官网

<https://www.processon.com/?utm_source=baidu&utm_medium=sem&utm_term=120470957204&utm_content=29213349358&uc_pagenum=1&uc_adposition=cl1&bd_vid=8058615066462846960>

<https://mubu.com/home>

### 下载地址(提取码：1jbz)

<https://pan.baidu.com/s/13TklqK9-tEAtiH1d0HcyeQ>

## 9.文献引用范式

![](image/image_hMUFjwbviY.png)

![](image/image_sOEogeh0RG.png)

<https://xueshu.baidu.com/>

## 10.实验室常用套件——Pasco Capstone

### 下载地址

<https://www.pasco.com/download/capstone/win64/c0e83e25/f522a0f6fd4e1b66>

